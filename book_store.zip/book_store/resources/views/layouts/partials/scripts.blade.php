<script src="{{asset('assets/plugins/jquery/jquery-3.5.1.min.js')}}"></script>
<script src="{{asset('assets/plugins/animsition/js/animsition.min.js')}}"></script>
<script src="{{asset('assets/plugins/bootstrap/js/bootstrap.min.js')}}"></script>
