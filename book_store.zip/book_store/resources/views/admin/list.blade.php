@extends('layouts.app')

@section("extra-css")
    <link rel="stylesheet" type="text/css" href="{{asset('assets/plugins/datatables/DataTables/css/jquery.dataTables.min.css')}}">
    <style>
        #add_new {
            float: right
        }
    </style>
@endsection

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div style="display: none;" class="alert alert-success"></div>
                <div class="card">
                    <div class="card-header">
                        Book List
                        <a href="{{url('admin/books/create')}}" id="add_new" class="btn btn-sm btn-info">Add New</a>
                    </div>
                    <div class="card-body">
                        @if(session()->has('success'))
                            <div class="alert alert-success">
                                {{ session()->get('success') }}
                            </div>
                        @endif
                        <table id="book_list" class="display">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Author</th>
                                <th>Published On</th>
                                <th>Publisher</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section("extra-scripts")
    <script src="{{asset("assets/plugins/datatables/datatables.min.js")}}"></script>
    <script src="{{asset("assets/js/book.js?v=1.1")}}"></script>
    <script>
        Book.initDatatables();
    </script>
@endsection
