@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">{{ ucfirst($actionType) }} Book</div>

                    <div class="card-body">
                        <form id="add_book_form" method="post" enctype="multipart/form-data">
                            @csrf
                            @if($actionType !== 'add') @method('put') @endif
                            @if ($errors->any())
                                <div class="alert alert-danger">
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <label for="title">Title</label>
                                    <input type="text" name="title" id="title" class="form-control" value="{{old('title')}}{{ @$data['title'] }}" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="author">Author</label>
                                    <input type="text" name="author" id="author" class="form-control" value="{{old('author')}}{{ @$data['author'] }}" required>
                                </div>
                            </div>

                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <label for="description">Description</label>
                                    <input type="text" name="description" id="description" class="form-control" value="{{old('description')}}{{ @$data['description'] }}" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="image">Image</label>
                                    @if(isset($data['image']))
                                        <img src="{{asset('storage/'.$data['image'])}}" alt="book_image"
                                         class="img-thumbnail">
                                        <input type="file" name="image" id="image" class="form-control" value="{{old('image')}}{{ @$data['image'] }}">
                                    @else
                                        <input type="file" name="image" id="image" class="form-control" value="{{old('image')}}" required>
                                    @endif
                                </div>
                            </div>

                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <label for="published">Published On</label>
                                    <input type="date" name="published" id="published" class="form-control" value="{{ old('published') ?: (isset($data['published']) ? \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $data['published'])->format('Y-m-d') : '') }}"  required>
                                </div>
                                <div class="col-md-6">
                                    <label for="publisher">Publisher</label>
                                    <input type="text" name="publisher" id="publisher" class="form-control" value="{{old('publisher')}}{{ @$data['publisher'] }}" required>
                                </div>
                            </div>


                            <div class="row">
                                <div class="col-md-12">
                                    <a style="float: right" class="btn btn-warning" href="{{ url('/admin/books') }}">Cancel</a>
                                    <button type="submit" class="btn btn-success mr-2" style="float: right">
                                        Submit
                                    </button>
                                </div>
                            </div>

                            <label for=""></label>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('extra-scripts')
    <script src="{{asset("assets/plugins/jquery-validation/jquery.validate.min.js")}}"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>

    <script src="{{asset("assets/js/book.js")}}"></script>
    <script>
        Book.validateAddForm('{{ $actionType }}', {{ optional(@$data)->id ?? 0 }});
    </script>
@endsection
