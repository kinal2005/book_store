<?php 

namespace App\Helpers;

class Helper
{

	public function __construct()
	{

	}

	public static function customResponse($status, $message, $data = null)
	{
		$response = [
            'statusCode' => $status,
            'message' => $message,
        ];

        if ($data !== null) {
            $response['data'] = $data;
        }

        return response()->json($response);
	}

}
