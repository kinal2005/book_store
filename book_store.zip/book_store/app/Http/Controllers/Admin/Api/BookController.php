<?php

namespace App\Http\Controllers\Admin\Api;

use App\Helpers\Helper;
use App\Http\Controllers\Controller;
use App\Models\BookStores;
use App\Models\User;
use Auth;
use Carbon\Carbon;
use Config;
use DataTables;
use Illuminate\Http\Request;
use URL;
use Validator;

class BookController extends Controller {
    public function login(request $request) {
        try
        {
            $data      = $request->only('email', 'password');
            $validator = Validator::make($request->only('email', 'password'), [
                    'email'    => 'required|email',
                    'password' => 'required',
                ]);

            if ($validator->fails()) {
                return response()->json(['error' => $validator->errors()], 500);
            }

            if (!Auth::attempt($request->only(['email', 'password']))) {
                return Helper::customResponse(401, 'The provided email address or password does not match our records.');
            }

            $user = User::where('email', $request->email)->first();

            return Helper::customResponse(200, 'Logged In Successfully.', $user->createToken(Config::get('app.name'))->plainTextToken);
        }
         catch (\Throwable $th) {
            return Helper::customResponse(500, $th->getMessage());
        }
    }

    public function getTitle(request $request) {
        try
        {
            $bookData = [];
            if (isset($request['search_value'])) {
                $bookData = BookStores::select('id', 'title')->where('title', 'LIKE', "%{$request['search_value']}%")->get()->toArray();
            }
            return Helper::customResponse(200, 'success.', $bookData);
        }
         catch (\Throwable $th) {
            return Helper::customResponse(500, $th->getMessage());
        }
    }

    /**
     * Display a listing of the resource.
     */
    public function index() {
        try
        {
            $books = BookStores::latest()->get();

            return Datatables::of($books)
            ->addIndexColumn()
            ->addColumn('action', function ($row) {
                    $actionBtn = '<a href="'.URL::to("admin/books/".$row->id."/edit").'" class="edit btn btn-success btn-sm">Edit</a>
            <a href="#" data-id="'.$row->id.'" onclick="deleteRecord(this)" class="delete btn btn-danger btn-sm">Delete</a>';
                    return $actionBtn;
                })
            ->rawColumns(['action'])
            ->make(true);
        }
         catch (\Throwable $th) {
            return Helper::customResponse(500, $th->getMessage());
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(request $request) {
        try
        {
            $data      = $request->all();
            $validator = Validator::make($data, [
                    'title'       => 'required|min:6|max:20',
                    'author'      => 'required|min:6|max:20',
                    'description' => 'required|min:6|max:500',
                    'image'       => 'required|mimes:jpeg,jpg,png|max:10000',
                    'published'   => 'required',
                    'publisher'   => 'required|min:6|max:20',
                ]);

            if ($validator    ->fails()) {
                return response()->json(['error' => $validator->errors()], 500);
            }
            $imagePath = $request->file('image')->store('image', 'public');

            $data = BookStores::create([
                    'title'       => $data['title'],
                    'author'      => $data['author'],
                    'description' => $data['description'],
                    'published'   => Carbon::createFromFormat('Y-m-d', $data['published'])->format('Y-m-d H:i:s'),
                    'publisher'   => $data['publisher'],
                    'image'       => $imagePath,
                ]);

            return Helper::customResponse(200, 'Data stored Successfully');

        }
         catch (\Throwable $th) {
            return Helper::customResponse(500, $th->getMessage());
        }
    }

    public function update(Request $request, $id) {
        try
        {
            $validator = Validator::make(['id' => $id], [
                'id' => 'required|exists:book_stores,id',
            ]);

            if ($validator->fails()) {
                return response()->json(['error' => $validator->errors()], 500);
            }

            $data      = $request->all();
            $validator = Validator::make($data, [
                    'title'       => 'required|min:6|max:20',
                    'author'      => 'required|min:6|max:20',
                    'description' => 'required|min:6|max:500',
                    'image'       => 'nullable|mimes:jpeg,jpg,png|max:10000',
                    'published'   => 'required',
                    'publisher'   => 'required|min:6|max:20',
                ]);

            if ($validator->fails()) {
                return response()->json(['error' => $validator->errors()], 500);
            }

            $book              = BookStores::findOrFail($id);
            $book->title       = $request->get('title');
            $book->author      = $request->get('author');
            $book->description = $request->get('description');
            $book->published   = $request->get('published');
            $book->publisher   = $request->get('publisher');

            if ($request->hasFile('image')) {
                $imagePath   = $request->file('image')->store('image', 'public');
                $book->image = $imagePath;
            }

            $book->save();
            return Helper::customResponse(200, 'Data updated Successfully');
        }
         catch (\Throwable $th) {
            return Helper::customResponse(500, $th->getMessage());
        }

    }

    public function destroy($bookId) {
        try
        {
            $validator = Validator::make(['id' => $bookId], [
                'id' => 'required|exists:book_stores,id',
            ]);

            if ($validator->fails()) {
                return response()->json(['error' => $validator->errors()], 500);
            }

            $book = BookStores::whereId($bookId)->first();
            if ($book->delete()) {
                return Helper::customResponse(200, 'Data Deleted Successfully.');
            } else {
                return Helper::customResponse(200, 'Failed to delete data.');
            }
        }
        catch (\Throwable $th) {
            return Helper::customResponse(500, $th->getMessage());
        }
    }

    public function getBookDetails(Request $request) {
        try
        {
            $bookId    = $request->input('bookId');
            $validator = Validator::make(['id' => $bookId], [
                    'id' => 'required|exists:book_stores,id',
                ]);

            if ($validator->fails()) {
                return response()->json(['error' => $validator->errors()], 500);
            }
            if ($bookId) {
                $book = BookStores::findOrFail($bookId);
                return Helper::customResponse(200, 'Data fetched Successfully.', $book);
            } else {
                return Helper::customResponse(500, 'No Data Found.');
            }
        }
         catch (\Throwable $th) {
            return Helper::customResponse(500, $th->getMessage());
        }
    }
}
