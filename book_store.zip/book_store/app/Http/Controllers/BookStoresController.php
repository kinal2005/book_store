<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\BookStores;

class BookStoresController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view("user.search");
    }

    public function getBookDetails($bookId)
    {
        $bookData = BookStores::findOrFail($bookId);
        return view("user.book_details", compact('bookData'));
    }

}
