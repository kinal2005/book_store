<script src="<?php echo e(asset('assets/plugins/jquery/jquery-3.5.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/animsition/js/animsition.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>
<?php /**PATH C:\laragon\www\book_store\resources\views/layouts/partials/scripts.blade.php ENDPATH**/ ?>