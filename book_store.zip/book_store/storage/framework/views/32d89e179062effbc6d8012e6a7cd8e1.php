<?php $__env->startSection("extra-css"); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/plugins/datatables/DataTables/css/jquery.dataTables.min.css')); ?>">
    <style>
        #add_new {
            float: right
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div style="display: none;" class="alert alert-success"></div>
                <div class="card">
                    <div class="card-header">
                        Book List
                        <a href="<?php echo e(url('admin/books/create')); ?>" id="add_new" class="btn btn-sm btn-info">Add New</a>
                    </div>
                    <div class="card-body">
                        <?php if(session()->has('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session()->get('success')); ?>

                            </div>
                        <?php endif; ?>
                        <table id="book_list" class="display">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Author</th>
                                <th>Published On</th>
                                <th>Publisher</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("extra-scripts"); ?>
    <script src="<?php echo e(asset("assets/plugins/datatables/datatables.min.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/js/book.js?v=1.1")); ?>"></script>
    <script>
        Book.initDatatables();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\book_store\resources\views/admin/list.blade.php ENDPATH**/ ?>