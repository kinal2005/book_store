<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- CSRF Token -->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<title><?php echo e(config('app.name', 'Laravel')); ?></title>

<!-- Fonts -->
<link rel="dns-prefetch" href="//fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/plugins/bootstrap/css/bootstrap.min.css')); ?>">

<script>
    const base_url = '<?php echo e(url('/')); ?>';
    const csrf_token = '<?php echo e(csrf_token()); ?>';
</script>
<style>
    label.error {
        font-size: 12px;
        color: red;
    }
    .dataTables_length label,.dataTables_filter label {
        display: flex;
    }
</style>
<?php /**PATH C:\laragon\www\book_store\resources\views/layouts/partials/htmlheader.blade.php ENDPATH**/ ?>