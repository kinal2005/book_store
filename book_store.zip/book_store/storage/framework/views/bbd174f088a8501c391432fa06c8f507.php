
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <a class="btn btn-success btn-sm float-right mb-3" href="<?php echo e(URL('/')); ?>">Back To Search</a>
                <div class="card" style="width: 100%">

                    <div class="card-body">
                    <h4> Book Details Of <?php echo e(ucwords($bookData['title'])); ?></h4>
                       
                       <table class="table">
                           <tr>
                               <td>
                                   <label>Title</label>
                               </td>
                               <td id="title">
                               </td>
                           </tr>
                           <tr>
                               <td>
                                   <label>Author</label>
                               </td>
                               <td id="author">
                               </td>
                           </tr>
                           <tr>
                               <td>
                                   <label>Description</label>
                               </td>
                               <td id="description">
                               </td>
                           </tr>
                            <tr>
                               <td>
                                   <label>Image</label>
                               </td>
                               <td id="book_image">
                               </td>
                           </tr>
                           <tr>
                               <td>
                                   <label>Published Date</label>
                               </td>
                               <td id="published">
                               </td>
                           </tr>
                           <tr>
                               <td>
                                   <label>Publisher</label>
                               </td>
                               <td id="publisher">
                               </td>
                           </tr>
                       </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("extra-scripts"); ?>
<script type="text/javascript">
  var dataString = localStorage.getItem('apiData');
  var data = JSON.parse(dataString);
  var baseUrl = '<?php echo e(url("/")); ?>';
  var inputDate = new Date(data.published);
  var options = { year: 'numeric', month: 'long', day: 'numeric' };
  var formattedDate = inputDate.toLocaleDateString('en-US', options);
  $('#title').text(data.title);
  $('#author').text(data.author);
  $('#genre').text(data.genre);
  $('#description').text(data.description);
  $('#isbn').text(data.isbn);
  $('#book_image').html('<img src="' + baseUrl+'/storage/'+data.image + '" alt="Book Image" width="30%" height="30%">');
  $('#published').text(formattedDate);
  $('#publisher').text(data.publisher);
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.appUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\book_store\resources\views/user/book_details.blade.php ENDPATH**/ ?>