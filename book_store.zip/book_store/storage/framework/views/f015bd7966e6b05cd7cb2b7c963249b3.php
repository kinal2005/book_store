<?php $__env->startSection("extra-css"); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/plugins/datatables/DataTables/css/jquery.dataTables.min.css')); ?>">
    <style>
        #add_new {
            float: right
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">

                <form id="search_book_form" class="flex-sb flex-w">
                <?php echo csrf_field(); ?>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6 offset-md-3">
                                <label>Serach Book Title</label>
                                <input type="text" name="book_search" id="book_search" class="form-control mb-1" placeholder="search here.." required>
                                <button type="submit" id="btn-search" class="btn btn-success btn-block">Search</button>
                            </div>
                        </div>
                    </div>
                </form>

                <div class="card-body col-md-6 offset-md-3">                   
                    <table id="book_list" class="display table">
                        <thead>
                            <tr>
                                <th>Book Titles</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("extra-scripts"); ?>
    <script src="<?php echo e(asset("assets/plugins/jquery-validation/jquery.validate.min.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/js/search.js")); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.appUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\book_store\resources\views/user/search.blade.php ENDPATH**/ ?>