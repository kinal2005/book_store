<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(ucfirst($actionType)); ?> Book</div>

                    <div class="card-body">
                        <form id="add_book_form" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php if($actionType !== 'add'): ?> <?php echo method_field('put'); ?> <?php endif; ?>
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <label for="title">Title</label>
                                    <input type="text" name="title" id="title" class="form-control" value="<?php echo e(old('title')); ?><?php echo e(@$data['title']); ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="author">Author</label>
                                    <input type="text" name="author" id="author" class="form-control" value="<?php echo e(old('author')); ?><?php echo e(@$data['author']); ?>" required>
                                </div>
                            </div>

                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <label for="description">Description</label>
                                    <input type="text" name="description" id="description" class="form-control" value="<?php echo e(old('description')); ?><?php echo e(@$data['description']); ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="image">Image</label>
                                    <?php if(isset($data['image'])): ?>
                                        <img src="<?php echo e(asset('storage/'.$data['image'])); ?>" alt="book_image"
                                         class="img-thumbnail">
                                        <input type="file" name="image" id="image" class="form-control" value="<?php echo e(old('image')); ?><?php echo e(@$data['image']); ?>">
                                    <?php else: ?>
                                        <input type="file" name="image" id="image" class="form-control" value="<?php echo e(old('image')); ?>" required>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <label for="published">Published On</label>
                                    <input type="date" name="published" id="published" class="form-control" value="<?php echo e(old('published') ?: (isset($data['published']) ? \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $data['published'])->format('Y-m-d') : '')); ?>"  required>
                                </div>
                                <div class="col-md-6">
                                    <label for="publisher">Publisher</label>
                                    <input type="text" name="publisher" id="publisher" class="form-control" value="<?php echo e(old('publisher')); ?><?php echo e(@$data['publisher']); ?>" required>
                                </div>
                            </div>


                            <div class="row">
                                <div class="col-md-12">
                                    <a style="float: right" class="btn btn-warning" href="<?php echo e(url('/admin/books')); ?>">Cancel</a>
                                    <button type="submit" class="btn btn-success mr-2" style="float: right">
                                        Submit
                                    </button>
                                </div>
                            </div>

                            <label for=""></label>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-scripts'); ?>
    <script src="<?php echo e(asset("assets/plugins/jquery-validation/jquery.validate.min.js")); ?>"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>

    <script src="<?php echo e(asset("assets/js/book.js")); ?>"></script>
    <script>
        Book.validateAddForm('<?php echo e($actionType); ?>', <?php echo e(optional(@$data)->id ?? 0); ?>);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\book_store\resources\views/admin/create.blade.php ENDPATH**/ ?>