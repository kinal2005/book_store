<?php
 ?><?php /**PATH C:\laragon\www\book_store\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>