$(document).ready(function() {

    if (!localStorage.getItem('auth_token')) {
        window.location.href = '/admin';
    }
    const successMessage = localStorage.getItem('successMessage');
    
    if (successMessage) {
        $('.alert').show();
        $('.alert').text(successMessage);

        localStorage.removeItem('successMessage');
        setTimeout(function() {
            $('.alert').fadeOut(1000);
        }, 7000);
    }
});

function deleteRecord(link) {
    var recordId = $(link).data('id');
    $.ajax({
        url: base_url + '/api/admin/books/'+recordId,
        headers: {"Authorization": 'Bearer ' + localStorage.getItem('auth_token')},
        method: 'DELETE',
        data: [{data : recordId}],
        success: function(response) {
            localStorage.setItem('successMessage', response.message);
            window.location.href = "/admin/books";
        }            
    });
    
}

const Book = function () {

    const initDatatables = () => {
        $('#book_list').DataTable({
            serverSide: true,
            pageLength: 10,
            "order": [[0, 'desc']],
            ajax: {
                'url': base_url + '/api/admin/books',
                'type': 'GET',
                'beforeSend': function (request) {
                    request.setRequestHeader("Authorization", 'Bearer ' + localStorage.getItem('auth_token'));
                },
                error: function(error) {
                    if (error.responseJSON.message === 'Unauthenticated.') {
                        localStorage.removeItem('auth_token');
                        window.location.href = '/admin'
                    }
                }
            },
            
            aoColumns: [
                {data: 'id', name: 'id'},
                {data: 'title', name: 'title'},
                {data: 'author', name: 'author'},
                {data: 'published', name: 'published',
                    render: function(data, type, row) {
                        var date = new Date(data);
                        var options = { month: 'long', day: 'numeric', year: 'numeric' };
                        return date.toLocaleDateString('en-US', options);
                    }
                },

                {data: 'publisher', name: 'publisher'},
                {data: 'action', name: 'action', searchable: false, orderable: false}
            ]
        });
    };

    const refreshDatatables = () => {
        $('#book_list').DataTable().ajax.reload();
    };

    const validateAddForm = (actionType = 'add', id = 0) => {
        $('#add_book_form').validate({
            rules: {
                title: {
                    required: true,
                    minlength: 6,
                    maxlength: 20
                },
                author: {
                    required: true,
                    minlength: 6,
                    maxlength: 20
                },
                genre: {
                    required: true,
                    minlength: 6,
                    maxlength: 20
                },
                description: {
                    required: true,
                    minlength: 6,
                    maxlength: 500
                },
                isbn: {
                    required: true,
                    minlength: 6,
                    maxlength: 15,
                    number: true
                },
                image: {
                    required: actionType?.toLowerCase() === 'add',
                    extension: "jpg|jpeg|png"
                },
                published: {
                    required: true,
                    date: true,
                },
                publisher: {
                    required: true,
                    minlength: 6,
                    maxlength: 20
                }
            },

            submitHandler: function(form) {
                $.ajax({
                    url: base_url + (actionType?.toLowerCase() === 'add' ? '/api/admin/books' : `/api/admin/books/${id}`),
                    headers: {"Authorization": 'Bearer ' + localStorage.getItem('auth_token')},
                    method: 'POST',
                    data: new FormData(form),
                    cache: false,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        localStorage.setItem('successMessage', response.message);
                        window.location.href = "/admin/books";
                    },
                    error: function(error) {
                        if (error.responseJSON.message === 'Unauthenticated.') {
                            localStorage.removeItem('auth_token');
                            window.location.href = '/admin'
                        }
                    }

                });
            }
        });
    };

    return {
        initDatatables: initDatatables,
        refreshDatatables: refreshDatatables,
        validateAddForm: validateAddForm
    }
}();
