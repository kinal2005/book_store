$(document).ready(function () {
$('.card-body').hide();
        $("#search_book_form").validate({
            rules: {
                book_search: {
                    required: true,
                    minlength: 3,
                },
            },
            submitHandler: function (form) {
                makeAjaxRequest();
            },
        });

        function makeAjaxRequest() {
            var search_value = $('#book_search').val();
            $.ajax({
                url: base_url + '/api/admin/get-title',
                method: 'POST',
                data: {
                    'search_value': search_value,
                },
                dataType: "json",
                success: function (response) {
                    $('.card-body').show();
                    var table = $('#book_list tbody');

                    if (response.data.length == 0) {
                        var newRow = $('<tr><td>No matching books</td></tr>');
                        table.html(newRow);
                    } else {
                        var data = response.data;
                        table.html('');
                        for (var i = 0; i < data.length; i++) {
                            var row = $('<tr>');
                            var title = data[i].title;
                            var id = data[i].id;
                            // var link = $('<a>').attr('href', base_url + '/book/' + id).text(title);
                            var link = $('<a>', {
                                          id: id,
                                          class: 'bookId_'+id,
                                          text: title
                                        });

                            var cell = $('<td>').append(link);
                            row.append(cell);
                            table.append(row);
                        }

                         $('[class^="bookId_"]').on('click', function() {
                            var bookId = $(this).attr('id');
                            console.log(bookId);
                            $.ajax({
                                url: base_url + '/api/admin/get-book-details',
                                method: 'POST',
                                data: { bookId: bookId },
                                success: function (response) {
                                    console.log(response);
                                    var data = response.data;
                                    localStorage.setItem('apiData', JSON.stringify(data));
                                    window.location.href = '/book/'+data.id;

                                },
                                error: function (error) {
                                    console.error("Error fetching data:", error);
                                }
                            });
                        });
                    }
                },
                error: function (error) {
                    console.log(error);
                }
            });
        }

    $("#btn-search").click(function () {
        $("#search_book_form").submit();
    });
});