
(function ($) {
    "use strict";


    /*==================================================================
    [ Validate ]*/
    var input = $('.validate-input .input100');

$('.validate-form').validate({
    rules: {
        email: {
            required: true,
            email: true
        },
        password: {
            required: true,
        },
    },
    messages: {
        email: {
            required: "Please enter your email",
            email: "Please enter a valid email address"
        },
        password: {
            required: "Please enter your password",
        },
    },
    submitHandler: function(form) {
        $.ajax({
            url: base_url + '/api/admin/login',
            headers: {"Authorization": 'Bearer ' + localStorage.getItem('auth_token')},
            method: 'POST',
            data: $(form).serialize(),
            success: function(response) {

                localStorage.setItem('auth_token', response.data);
                location.href = base_url+"/admin/books";
            },
            error: function(error) {
                const errorMessage = error.responseJSON.message;
                $('.login-error').show();
                $('.login-error').text(errorMessage);
            }         
        });
    }
});



    $('.validate-form .input100').each(function(){
        $(this).focus(function(){
           hideValidate(this);
        });
    });

    function validate (input) {
        if($(input).attr('type') == 'email' || $(input).attr('name') == 'email') {
            if($(input).val().trim().match(/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)$/) == null) {
                return false;
            }
        }
        else {
            if($(input).val().trim() == ''){
                return false;
            }
        }
    }

    function showValidate(input) {
        var thisAlert = $(input).parent();

        $(thisAlert).addClass('alert-validate');
    }

    function hideValidate(input) {
        var thisAlert = $(input).parent();

        $(thisAlert).removeClass('alert-validate');
    }
    
    /*==================================================================
    [ Show pass ]*/
    var showPass = 0;
    $('.btn-show-pass').on('click', function(){
        if(showPass == 0) {
            $(this).next('input').attr('type','text');
            $(this).find('i').removeClass('fa-eye');
            $(this).find('i').addClass('fa-eye-slash');
            showPass = 1;
        }
        else {
            $(this).next('input').attr('type','password');
            $(this).find('i').removeClass('fa-eye-slash');
            $(this).find('i').addClass('fa-eye');
            showPass = 0;
        }
        
    });
    

})(jQuery);