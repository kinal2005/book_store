<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Auth::routes();

Route::get('/hello', function () {
    return 'Hello, Laravel!';   
});

Route::get('/', [App\Http\Controllers\BookStoresController::class, 'index']);
Route::get('/book/{bookId}', [App\Http\Controllers\BookStoresController::class, 'getBookDetails'])->name('getBookDetails');

Route::get('/admin', function () {
    return view('auth.login');   
});

Route::resource('/admin/books', \App\Http\Controllers\Admin\BookStoresController::class)->only(['index', 'create', 'edit']);
